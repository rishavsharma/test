import json
import requests
from pathlib import Path
import urllib3
from requests_ntlm import HttpNtlmAuth
from pathlib import Path
import binascii
from requests_ntlm import HttpNtlmAuth
import getpass


def print(records: []):
    for r in records:
        pass


def getFolderReports(folder):
    resp = requests.get(searchFolderUrl.format(folder), auth=ha, verify=False)
    data = resp.json()
    retList = []
    for v in data['value']:
        leng = len(v['Name']) * -1
        fp = v['Path']
        foldp = fp[0:leng]
        r = (v['Id'], v['Name'], foldp)
        retList.append(r)
    return retList


def getFolderReportsDict(folder):
    resp = requests.get(searchFolderUrl.format(folder), auth=ha, verify=False)
    data = resp.json()
    retList = []
    for v in data['value']:
        leng = len(v['Name']) * -1
        fp = v['Path']
        foldp = fp[0:leng]
        r = {
            "id": v['Id'],
            "name": v['Name'],
            "folder": foldp}
        retList.append(r)
    return retList


def getAllReports():
    resp = requests.get(baseurl, auth=ha, verify=False)
    data = resp.json()
    retList = []
    for v in data['value']:
        leng = len(v['Name']) * -1
        fp = v['Path']
        foldp = fp[0:leng]
        r = (v['Id'], v['Name'], foldp)
        retList.append(r)
    return retList


def getAllReportsDict():
    resp = requests.get(baseurl, auth=ha, verify=False)
    print(resp.text)
    data = resp.json()

    retList = []
    for v in data['value']:
        leng = len(v['Name']) * -1
        fp = v['Path']
        foldp = fp[0:leng]
        r = {
            "id": v['Id'],
            "name": v['Name'],
            "folder": foldp}
        retList.append(r)
    return retList


def updateDatasource(reportID, connectString):
    dsURL = dataSourecURL.format(reportID)
    resp = requests.get(dsURL, auth=ha, verify=False)
    da = resp.json()
    da['value'][0]['ConnectionString'] = connectString
    da['value'][0]['IsConnectionStringOverridden'] = True
    headers = {'content-type': 'application/json'}
    resp = requests.patch(dsURL, data=json.dumps(
        da['value']), auth=ha, headers=headers, verify=False)
    return resp.status_code


def getPath(reportID):
    resp = requests.get(baseurl+"("+reportID+")", auth=ha, verify=False)
    res = resp.json()
    return res['Path']


def getReportAttr(reportID, attr):
    resp = requests.get(baseurl+"("+reportID+")", auth=ha, verify=False)
    res = resp.json()
    return res[attr]


def uploadReport(filePath, fileName, targetPath):
    try:
        FILE = open(filePath, "rb")
        file_data = binascii.b2a_base64(FILE.read()).decode('utf-8')
        FILE.close()

        data = {"Name": fileName, 'Content': file_data.rstrip(),
                "Path": targetPath}
        st = json.dumps(data)
        resp = requests.post(baseurl, data=st, auth=ha, verify=False, headers={
                             "content-type": "application/json"})
        return resp.ok
    except Exception as e:
        print(str(e))
        return False


def downloadReport(reportID, folder, reportName=None):
    try:
        if reportName is None:
            reportName = getReportAttr(reportID, 'Name') + ".pbix"
        urld = baseurl+'('+reportID+')/Content/$value'
        Path(folder).mkdir(parents=True, exist_ok=True)
        resp = requests.get(urld, auth=ha, verify=False)
        with open(folder+'\\'+reportName, 'wb') as f:
            f.write(resp.content)
        return True
    except Exception as e:
        print(str(e))
        return False


if __name__ == "__main__":
    # downloadReport('bf974756-18cb-4e1a-8d24-6c44ee436962','31 to 90 Days PD Ratio_2019',"D:\\BTS")
    # uploadReport("D:\\BTS\\31 to 90 Days PD Ratio_2019.pbix",'31 to 90 Days PD Ratio_2','/Pilot/BTS/31 to 90 Days PD Ratio_2')
    # downloadReport('bf974756-18cb-4e1a-8d24-6c44ee436962',"D:\\BTS")
    # writeExcel()
    rsServer = "http://pf0yvtlf/"
    rsServerAPI = rsServer+"ReportServer/api/v2.0/PowerBIReports"
    try:
        p = getpass.getpass()
    except Exception as error:
        print('ERROR', error)
    else:
        ha = HttpNtlmAuth('user', p)
        baseurl = rsServer + rsServerAPI
        searchFolderUrl = baseurl+"?$filter=startsWith(Path,'{0}')"
        dataSourecURL = baseurl+"({0})/DataSources"
        print(getFolderReportsDict('/test'))
