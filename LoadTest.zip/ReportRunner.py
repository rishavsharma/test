from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import xlsxwriter
from io import BytesIO
from pathlib import Path
import logging
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import argparse


class ReportRunner:

    def __init__(self, browser, rsServer):
        profile = webdriver.FirefoxProfile()
        profile.accept_untrusted_certs = True
        options = Options()
        options.headless = False
        options.accept_insecure_certs = True
        self.MAX_WAIT_REPORT = 1800
        self.LOGIN_ENABLED = False
        self._RIGHT_PANE_CLASS = 'outspacePane'  # 'rightSidePane'
        self._SPINNER_CLASS = 'spinner'
        self._SECTION_CSS = 'li.section:not(.hidden-in-view-mode) div.textLabel'
        self._ERROR_CSS = 'a.errorSeeMore'
        self.user = ''
        self.password = ''
        self.rsServer = rsServer
        self.baseUrl = self.rsServer+"powerbi/?id="
        if browser == "Firefox":
            self.driver = webdriver.Firefox(
                options=options, firefox_profile=profile)
        else:
            self.driver = webdriver.Chrome()

    def getSections(self, id):
        retSection = []
        self.driver.get(self.baseUrl+id)
        if self.LOGIN_ENABLED:
            try:
                alert = WebDriverWait(self.driver, 10).until(
                    EC.alert_is_present())
                alert.send_keys(self.user + Keys.TAB + self.password)
                alert.accept()
            except:
                pass
                print("No alert present")

        try:
            WebDriverWait(self.driver, 20).until(
                EC.visibility_of_element_located(((By.CLASS_NAME, self._RIGHT_PANE_CLASS))))
        except:
            print("getSection:Page didn't load properly")

        section = self.driver.find_elements_by_css_selector(
            self._SECTION_CSS)

        for el in section:
            retSection.append(el.get_attribute('title'))

        return retSection

    def runReportBySection(self, id, section):
        sc = BytesIO()
        sc.write(b"")
        time_taken = -1
        reportStatus = False
        try:
            self.driver.get(self.baseUrl+id)
            if self.LOGIN_ENABLED:
                try:
                    alert = WebDriverWait(self.driver, 10).until(
                        EC.alert_is_present())
                    alert.send_keys(self.user + Keys.TAB + self.password)
                    alert.accept()
                except:
                    pass
                    print("No alert present")

            try:
                WebDriverWait(self.driver, 20).until(
                    EC.visibility_of_element_located(((By.CLASS_NAME, self._RIGHT_PANE_CLASS))))
            except Exception as e:
                print("Report By Section:Page didn't load properly")

            sectionsElement = self.driver.find_elements_by_css_selector(
                self._SECTION_CSS)
            for el in sectionsElement:
                if el.get_attribute('title') == section:
                    el.click()
                    break
            time.sleep(5)
            start_time = time.time()
            try:
                WebDriverWait(self.driver, self.MAX_WAIT_REPORT).until_not(
                    EC.presence_of_all_elements_located(((By.CLASS_NAME, self._SPINNER_CLASS))))
                reportStatus = True
            except Exception as e:
                print("Spinner still present")

            try:
                errorLink = self.driver.find_element_by_link_text(
                    'Show technical details')
                errorLink.click()
                reportStatus = False
            except Exception as e:
                pass

            try:
                errorLink = self.driver.find_elements_by_css_selector(
                    self._ERROR_CSS)
                if len(errorLink) > 0:
                    errorLink[0].click()
                    reportStatus = False
            except Exception as e:
                pass

        except Exception as e:
            print("Error Ocured:"+str(e))
        finally:
            end_time = time.time()
            # time.sleep(4)
            # sc = BytesIO(self.driver.get_screenshot_as_png())
            time_taken = int(end_time - start_time)
            loc = ""  # rsGetReports.getPAth(id)
            return {'time_taken': time_taken, 'image_data': "sc", "status": reportStatus, "path": loc}

    def runReportAllSection(self, reportID, name):
        status = False
        reportStatus = True
        retDict = {}
        try:
            print("Running Report:"+name)
            allsections = self.getSections(reportID)
            for sectName in allsections:
                print("#Running Section:"+sectName)
                rpt1 = self.runReportBySection(reportID, sectName)
                status = rpt1['status']
                if not status and reportStatus:
                    reportStatus = False
                print("Report [{0}][{1}]:".format(
                    name, sectName)+str(rpt1['time_taken']))
                retDict[sectName] = {"report": rpt1, 'status': status}
        except Exception as e:
            print("runReportAllSection:Error Ocured:"+str(e))
        finally:
            retDict['__status__'] = reportStatus
            self.driver.quit()
            return retDict

    def driverQuit(self):
        self.driver.quit()


if __name__ == '__main__':
    rsServer = "http://pf0yvtlf/"
    rr = ReportRunner("Chrome", rsServer)
    # rr.LOGIN_ENABLED = True
    # rr.user
    # rr.password
    # rr._RIGHT_PANE_CLASS = 'rightSidePane'
    rr.runReportAllSection('0ac54fb1-5a28-48d7-8d6f-11c6bfaa5b81', 'Test1')
